import 'package:eb_restaurantes/UI/search.dart';
import 'package:flutter/material.dart';
void main() => runApp(MaterialApp(
    title: 'Restaurantes',
    home: SearchRestaurant(),
    theme: ThemeData(primaryColor: Colors.red)));

