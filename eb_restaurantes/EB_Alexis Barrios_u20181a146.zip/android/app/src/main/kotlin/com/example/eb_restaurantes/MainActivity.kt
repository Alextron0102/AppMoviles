package com.example.eb_restaurantes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
